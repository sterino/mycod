//
//  DetailedOrganisationViewController.swift
//  diplomka
//
//  Created by Aidana on 07.06.2022.
//

import UIKit
class DetailedOrganisationViewController: UIViewController {
    var organisation: Organisation?

    @IBOutlet weak var descriptionLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
    }
    
    func setup(with organisation: Organisation) {
        self.organisation = organisation
        setupUI()
    }
    
    private func setupUI() {
        descriptionLabel.text = organisation?.description
    }

}
