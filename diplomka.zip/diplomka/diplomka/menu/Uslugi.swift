//
//  Uslugi.swift
//  diplomka
//
//  Created by Айдана on 06.06.2022.
//

import Foundation
import UIKit

struct Usluga {
    let title: String
    let image: UIImage?
}

struct Organisation {
    let name: String
    let description: String
    let address: String
    let number: String
    let whatsAppLink: String
    let imageName: String
}
let uslugiArray = ["hirurg", "hirurg", "hirurg", "hirurg", "hirurg", "hirurg"]
let uslugiMap: [String: [Organisation]] = ["hirurg": [Organisation(name: "fff",
                                                                   description: "fffffff",
                                                                   address: "fff",
                                                                   number: "123",
                                                                   whatsAppLink: "fff",
                                                                   imageName: "fff"),
                                                      Organisation(name: "fff",
                                                                   description: "fffffff",
                                                                   address: "fff",
                                                                   number: "123",
                                                                   whatsAppLink: "fff",
                                                                   imageName: "fff"),
                                                      Organisation(name: "fff",
                                                                   description: "fffffff",
                                                                   address: "fff",
                                                                   number: "123",
                                                                   whatsAppLink: "fff",
                                                                   imageName: "fff"),
                                                      Organisation(name: "fff",
                                                                   description: "fffffff",
                                                                   address: "fff",
                                                                   number: "123",
                                                                   whatsAppLink: "fff",
                                                                   imageName: "fff")],
                                           "zubvnoi": [Organisation(name: "fff",
                                                                    description: "fffffff",
                                                                    address: "fff",
                                                                    number: "123",
                                                                    whatsAppLink: "fff",
                                                                    imageName: "fff"),],
                                           "massag": [Organisation(name: "fff",
                                                                   description: "fffffff",
                                                                   address: "fff",
                                                                   number: "123",
                                                                   whatsAppLink: "fff",
                                                                   imageName: "fff"),],
                                           "diagnostika": [Organisation(name: "fff",
                                                                        description: "fffffff",
                                                                        address: "fff",
                                                                        number: "123",
                                                                        whatsAppLink: "fff",
                                                                        imageName: "fff"),],
                                           "Uzi": [Organisation(name: "fff",
                                                                description: "fffffff",
                                                                address: "fff",
                                                                number: "123",
                                                                whatsAppLink: "fff",
                                                                imageName: "fff"),],
                                           "Flurografia": [Organisation(name: "fff",
                                                                        description: "fffffff",
                                                                        address: "fff",
                                                                        number: "123",
                                                                        whatsAppLink: "fff",
                                                                        imageName: "fff"),],
                                           "laborotornye": [Organisation(name: "fff",
                                                                        description: "fffffff",
                                                                        address: "fff",
                                                                        number: "123",
                                                                        whatsAppLink: "fff",
                                                                        imageName: "fff"),]]
let uslugiTemp: [Usluga] = [
    Usluga(title: "hirurg", image: UIImage(named: "hirurg")),
    Usluga(title: "zubnoi", image: UIImage(named: "hubnoi")),
    Usluga(title: "massag", image: UIImage(named: "hirurg")),
    Usluga(title: "diagnostika", image: UIImage(named: "hirurg")),
    Usluga(title: "Uzi", image: UIImage(named: "hirurg")),
    Usluga(title: "Flurografia", image: UIImage(named: "hirurg")),
    Usluga(title: "laborotornye", image: UIImage(named: "hirurg")),
    Usluga(title: "terapia", image: UIImage(named: "hirurg")),
    Usluga(title: "oftalmologia", image: UIImage(named: "hirurg")),
    Usluga(title: "pediaterapia", image: UIImage(named: "hirurg")),
    Usluga(title: "kardiologia", image: UIImage(named: "hirurg")),
    Usluga(title: "endokrinologia", image: UIImage(named: "hirurg")),
    Usluga(title: "nevrologia", image: UIImage(named: "hirurg")),
    Usluga(title: "pediatria", image: UIImage(named: "hirurg")),
    Usluga(title: "urolog", image: UIImage(named: "hirurg")),
    Usluga(title: "dermatolog", image: UIImage(named: "hirurg")),
    Usluga(title: "ginekologia", image: UIImage(named: "hirurg")),
    Usluga(title: "kosmetologia", image: UIImage(named: "hirurg")),
    Usluga(title: "ortoped", image: UIImage(named: "hirurg")),
    Usluga(title: "psiholog", image: UIImage(named: "hirurg")),
    Usluga(title: "logoped", image: UIImage(named: "hirurg")),
    Usluga(title: "travmatolog", image: UIImage(named: "hirurg")),
    Usluga(title: "androlog", image: UIImage(named: "hirurg")),
]


