//
//  OrganisationsViewController.swift
//  diplomka
//
//  Created by Айдана on 06.06.2022.
//

import UIKit
class OrganisationsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var name: String?
    lazy var organisations: [Organisation] = [] {
        didSet {
            tableView.reloadData()
        }
    }
    

    let tableView: UITableView = {
        let tableView = UITableView()
        tableView.register(TableViewCell.self, forCellReuseIdentifier: "TableViewCell")
        return tableView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        title = name
        view.addSubview(tableView)
        tableView.frame = view.frame
        tableView.dataSource = self
        tableView.delegate = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return organisations.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
        cell.textLabel?.text = organisations[indexPath.row].name
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let vc = DetailedOrganisationViewController()
        vc.setup(with: organisations[indexPath.row])
        navigationController?.pushViewController(vc, animated: true)
    }
   
}
