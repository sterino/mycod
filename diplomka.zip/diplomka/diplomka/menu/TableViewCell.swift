//
//  TableViewCell.swift
//  diplomka
//
//  Created by Айдана on 07.06.2022.
//

import UIKit

class TableViewCell: UITableViewCell {

    static let id = "TableViewCell"
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
