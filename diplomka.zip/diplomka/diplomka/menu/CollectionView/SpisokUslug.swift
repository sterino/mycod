//
//  SpisokUslug.swift
//  diplomka
//
//  Created by Айдана on 06.06.2022.
//

import UIKit

class SpisokUslug: UICollectionViewCell {
    
    @IBOutlet weak var spisokImage: UIImageView!
    func setup(with uslugaName: String){
        spisokImage.image = UIImage(named: uslugaName)
        
    }
}
