//
//  Spisok.swift
//  diplomka
//
//  Created by Айдана on 06.06.2022.
//

import UIKit

class Spisok: UICollectionViewCell {
    
}
